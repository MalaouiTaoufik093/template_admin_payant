import React, { Component } from "react";
import { Empty } from "antd";

export class Simple extends Component {
  render() {
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  }
}

export default Simple;
